package com.zekelabs.kafka;

import java.util.concurrent.ExecutionException;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import com.zekelabs.kafka.constants.IKafkaConstants;
import com.zekelabs.kafka.consumer.ConsumerCreator;
import com.zekelabs.kafka.pojo.CustomObject;
import com.zekelabs.kafka.producer.ProducerCreator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.UUID;
import java.util.stream.Stream;

public class App {
	public static void main(String[] args) throws IOException {
        runProducer();
		runConsumer();
    
	}

	static void runConsumer() throws  IOException{
		Consumer<Long, String> consumer = ConsumerCreator.createConsumer();

		int noMessageToFetch = 0;
		final ConsumerRecords<Long, String> record = consumer.poll(1000);
		/*
		 * while (true) { final ConsumerRecords<Long, String> CsvRecord =
		 * consumer.poll(1000); if (CsvRecord.count() == 0) { noMessageToFetch++; if
		 * (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT) break; else
		 * continue; }
		 */
		BufferedWriter buffWriter = new BufferedWriter(new FileWriter("/home/edyoda/Desktop/Output/CsvFile.txt"));	
		for(ConsumerRecord<Long, String> recordNew : record) {
			buffWriter.write(value()+ System.lineSeparator());
			buffWriter.flush();}
		/*Stream<String> FileStream = Files.lines(Paths.get("/home/edyoda/Desktop/Output/CsvFile.txt"));
			FileStream.forEach(line -> {
			    final ConsumerRecords<Long, String> CsvRecord = new ConsumerRecords<Long, String>(IKafkaConstants.TOPIC_NAME,"Hello");
			
			    consumer.send(CsvRecord, (metadata, exception) ->*/ {
                    /*if(metadata != null){
                        System.out.println("CsvData: -> "+ CsvRecord.key()+" | "+ CsvRecord.value());
                    }
                    else{
                        System.out.println("Error Sending Csv Record -> "+ CsvRecord.value());
                    }*/
                }
            
			
			consumer.commitAsync();
		
		consumer.close();

	}

	
	private static String value() {
		// TODO Auto-generated method stub
		return null;
	}

	static void runProducer() throws  IOException {
		Producer<Long, String> producer = ProducerCreator.createProducer();
		
		//for (int index = 0; index < IKafkaConstants.MESSAGE_COUNT; index++) 
		//{
			//CustomObject c = new CustomObject();
			//c.setId(index+"");
			//c.setName(index+":name");
			final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(IKafkaConstants.TOPIC_NAME,"Hello");
			
			Stream<String> FileStream = Files.lines(Paths.get("/home/edyoda/Desktop/Input/CsvFile.txt"));
			FileStream.forEach(line -> {
			    final ProducerRecord<Long, String> CsvRecord = new ProducerRecord<Long, String>(IKafkaConstants.TOPIC_NAME,line);
			    //producer.send(CsvRecord);
			    producer.send(CsvRecord, (metadata, exception) -> {
                    if(metadata != null){
                        System.out.println("CsvData: -> "+ CsvRecord.key()+" | "+ CsvRecord.value());
                    }
                    else{
                        System.out.println("Error Sending Csv Record -> "+ CsvRecord.value());
                    }
                });
            });

			
	
}
}